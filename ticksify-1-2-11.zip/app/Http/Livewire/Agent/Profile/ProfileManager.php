<?php

namespace App\Http\Livewire\Agent\Profile;

use Livewire\Component;

class ProfileManager extends Component
{
    public function render()
    {
        return view('livewire.agent.profile.profile-manager');
    }
}
