<div>
    <div
        wire:click="logout"
        class="absolute inset-0"
    ></div>
    <span>{{ __('Sign out') }}</span>
</div>
