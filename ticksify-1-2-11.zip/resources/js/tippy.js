import {delegate} from 'tippy.js';
import 'tippy.js/dist/tippy.css';

delegate('#main', {
    target: '[data-tippy-content]',
});
